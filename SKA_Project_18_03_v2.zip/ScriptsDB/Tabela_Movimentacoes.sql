USE [ProjectSKA]
GO

/****** Object:  Table [dbo].[Movimentacoes]    Script Date: 11/03/2019 17:01:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Movimentacoes](
	[cd_movimentacao] [int] IDENTITY(1,1) NOT NULL,
	[cd_produto] [int] NOT NULL,
	[cd_usuario] [int] NOT NULL,
	[cd_filial_remetente] [int] NOT NULL,
	[cd_filial_destinataria] [int] NULL,
	[dt_movimentacao] [date] NOT NULL CONSTRAINT [DF_Movimentacoes_dt_movimentacao]  DEFAULT (getdate()),
 CONSTRAINT [PK_Movimentacoes] PRIMARY KEY CLUSTERED 
(
	[cd_movimentacao] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Movimentacoes]  WITH CHECK ADD  CONSTRAINT [FK_Movimentacoes_Filial_D] FOREIGN KEY([cd_filial_remetente])
REFERENCES [dbo].[Filiais] ([id])
GO

ALTER TABLE [dbo].[Movimentacoes] CHECK CONSTRAINT [FK_Movimentacoes_Filial_D]
GO

ALTER TABLE [dbo].[Movimentacoes]  WITH CHECK ADD  CONSTRAINT [FK_Movimentacoes_Filial_R] FOREIGN KEY([cd_filial_remetente])
REFERENCES [dbo].[Filiais] ([id])
GO

ALTER TABLE [dbo].[Movimentacoes] CHECK CONSTRAINT [FK_Movimentacoes_Filial_R]
GO

ALTER TABLE [dbo].[Movimentacoes]  WITH CHECK ADD  CONSTRAINT [FK_Movimentacoes_Produto] FOREIGN KEY([cd_produto])
REFERENCES [dbo].[Produtos] ([cd_produto])
GO

ALTER TABLE [dbo].[Movimentacoes] CHECK CONSTRAINT [FK_Movimentacoes_Produto]
GO

ALTER TABLE [dbo].[Movimentacoes]  WITH CHECK ADD  CONSTRAINT [FK_Movimentacoes_Usuario] FOREIGN KEY([cd_usuario])
REFERENCES [dbo].[Usuarios] ([cd_usuario])
GO

ALTER TABLE [dbo].[Movimentacoes] CHECK CONSTRAINT [FK_Movimentacoes_Usuario]
GO


